# 灵山胜境AI数字人智能导览系统

## 项目简介

基于微信小程序的AI数字人智能景区导览系统，为灵山胜境景区提供7x24小时智能导游服务。

## 技术栈

- **前端**：微信小程序（原生开发）
- **后端**：Node.js + Express
- **数据库**：MongoDB / JSON文件存储
- **AI能力**：多模态大模型API
- **语音技术**：讯飞语音识别/合成

## 项目结构

```
lingshan-miniprogram/
├── miniprogram/          # 小程序前端
│   ├── pages/            # 页面
│   ├── components/       # 组件
│   ├── utils/            # 工具函数
│   ├── assets/           # 静态资源
│   └── app.js/json/wxss
├── server/               # 后端服务
│   ├── api/              # API路由
│   ├── models/           # 数据模型
│   ├── services/         # 业务逻辑
│   ├── knowledge/        # 知识库
│   └── app.js            # 入口文件
└── admin/                # 管理后台（Web）
```

## 功能特性

### 游客交互端
- ✅ 多模态交互（语音/文本）
- ✅ 智能问答与讲解
- ✅ 个性化路线推荐
- ✅ 数字人虚拟导游
- ✅ 景点地图导航

### 管理后台
- ✅ 知识库管理
- ✅ 数字人形象配置
- ✅ 游客数据分析
- ✅ 运营数据大屏

## 快速开始

### 1. 小程序端
```bash
cd miniprogram
# 使用微信开发者工具打开项目
```

### 2. 后端服务
```bash
cd server
npm install
npm start
```

### 3. 管理后台
```bash
cd admin
npm install
npm run dev
```

## API文档

详见 [server/API.md](./server/API.md)

## 知识库

知识库数据位于 `server/knowledge/` 目录，包含：
- 景点信息数据
- 历史文化资料
- 常见问题解答
- 讲解词库

## 许可证

MIT License
