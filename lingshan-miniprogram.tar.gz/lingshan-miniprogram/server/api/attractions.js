// server/api/attractions.js - 景点API

const express = require('express');
const router = express.Router();
const attractionsData = require('../knowledge/attractions');

/**
 * 获取景点列表
 * GET /api/attractions
 */
router.get('/', (req, res) => {
  try {
    const { tag, limit } = req.query;
    let attractions = attractionsData.getAllAttractions();
    
    // 按标签筛选
    if (tag) {
      attractions = attractions.filter(a => 
        a.tags && a.tags.includes(tag)
      );
    }
    
    // 限制数量
    if (limit) {
      attractions = attractions.slice(0, parseInt(limit));
    }
    
    res.json({
      success: true,
      data: attractions,
      total: attractions.length
    });
  } catch (error) {
    res.status(500).json({ error: '获取景点列表失败' });
  }
});

/**
 * 获取景点详情
 * GET /api/attractions/:id
 */
router.get('/:id', (req, res) => {
  try {
    const { id } = req.params;
    const attraction = attractionsData.getAttraction(id);
    
    if (!attraction) {
      return res.status(404).json({ error: '景点不存在' });
    }
    
    // 获取相关景点
    const related = getRelatedAttractions(attraction);
    
    res.json({
      success: true,
      data: {
        ...attraction,
        relatedAttractions: related
      }
    });
  } catch (error) {
    res.status(500).json({ error: '获取景点详情失败' });
  }
});

/**
 * 搜索景点
 * GET /api/attractions/search/:keyword
 */
router.get('/search/:keyword', (req, res) => {
  try {
    const { keyword } = req.params;
    const attractions = attractionsData.getAllAttractions();
    
    const results = attractions.filter(a => 
      a.name.includes(keyword) || 
      a.highlight.includes(keyword) ||
      a.description.includes(keyword)
    );
    
    res.json({
      success: true,
      data: results,
      keyword
    });
  } catch (error) {
    res.status(500).json({ error: '搜索失败' });
  }
});

/**
 * 获取推荐景点
 * POST /api/attractions/recommend
 */
router.post('/recommend', (req, res) => {
  try {
    const { interests, visited } = req.body;
    let recommendations = attractionsData.recommendByInterests(interests || []);
    
    // 排除已访问的景点
    if (visited && visited.length > 0) {
      recommendations = recommendations.filter(a => 
        !visited.includes(a.id)
      );
    }
    
    res.json({
      success: true,
      data: recommendations.slice(0, 5)
    });
  } catch (error) {
    res.status(500).json({ error: '获取推荐失败' });
  }
});

// 辅助函数：获取相关景点
function getRelatedAttractions(attraction) {
  const allAttractions = attractionsData.getAllAttractions();
  return allAttractions
    .filter(a => a.id !== attraction.id)
    .filter(a => a.tags && attraction.tags && 
      a.tags.some(tag => attraction.tags.includes(tag)))
    .slice(0, 3);
}

module.exports = router;
