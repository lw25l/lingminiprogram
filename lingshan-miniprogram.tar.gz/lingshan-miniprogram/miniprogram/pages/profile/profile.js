// pages/profile/profile.js
const app = getApp();

Page({
  data: {
    loggedIn: false,
    userInfo: null,
    visitCount: 0,
    chatCount: 0,
    satisfactionScore: 4.8,
    showLogoutModal: false
  },

  onLoad() {
    this.checkLoginStatus();
    this.loadUserData();
  },

  // 检查登录状态
  checkLoginStatus() {
    const userInfo = app.globalData.userInfo;
    if (userInfo) {
      this.setData({
        loggedIn: true,
        userInfo: userInfo
      });
    }
  },

  // 加载用户数据
  loadUserData() {
    // 模拟数据
    this.setData({
      visitCount: Math.floor(Math.random() * 20) + 5,
      chatCount: Math.floor(Math.random() * 50) + 10,
      satisfactionScore: (4.5 + Math.random()).toFixed(1)
    });
  },

  // 跳转到登录页
  goToLogin() {
    wx.navigateTo({ url: '/pages/login/login' });
  },

  // 显示退出确认弹窗
  showLogoutModal() {
    this.setData({ showLogoutModal: true });
  },

  // 隐藏退出确认弹窗
  hideLogoutModal() {
    this.setData({ showLogoutModal: false });
  },

  // 执行退出
  doLogout() {
    app.globalData.userInfo = null;
    app.globalData.userId = null;
    wx.removeStorageSync('token');
    wx.removeStorageSync('userInfo');
    wx.reLaunch({ url: '/pages/index/index' });
  },

  // 跳转到路线页面
  goToRoute() {
    wx.switchTab({ url: '/pages/route/route' });
  },

  // 跳转到游览记录
  goToVisited() {
    wx.showToast({ title: '功能开发中', icon: 'none' });
  },

  // 跳转到意见反馈
  goToFeedback() {
    wx.showToast({ title: '功能开发中', icon: 'none' });
  },

  // 跳转到设置
  goToSettings() {
    wx.showToast({ title: '功能开发中', icon: 'none' });
  },

  // 显示已游览景点数量
  showVisitCount() {
    wx.showToast({ title: `已游览${this.data.visitCount}个景点`, icon: 'success' });
  },

  // 显示对话次数
  showChatHistory() {
    wx.showToast({ title: `共对话${this.data.chatCount}次`, icon: 'success' });
  },

  // 显示满意度
  showSatisfaction() {
    wx.showToast({ title: `满意度 ${this.data.satisfactionScore}分`, icon: 'success' });
  },

  // 编辑个人资料
  editProfile() {
    wx.showToast({ title: '功能开发中', icon: 'none' });
  }
});
